import random
n=random.randint(2,1000)
print(n)

if n>0:
    for i in range(2,n):
        creciente=2
        esPrimo=True
        while esPrimo and creciente<i:
            if i % creciente ==0 :
                esPrimo=False
            else:
                creciente +=1
        if esPrimo:
            print(i,end=",")
else:
    print("el numero ingresado no es correcto")
