#solo cuento los digitos si no da lo paso con un ciclo while y el if, else
from itertools import tee
def contar_digitos_letras(cadena):
    digitos = 0
    letras = 0

    for c in cadena:
        if c.isdigit():
            digitos += 1
        elif c.isalpha():
            letras += 1
        else:
            pass
    
    return digitos, letras


texto = input('Digite un texto: ')
resultado = contar_digitos_letras(texto)
lenguaje = '*'
for r in texto:
    print('**', end='')
print("\n*",texto,"*")
lenguaje = '*'
for r in texto:
    print('**', end='')



    
