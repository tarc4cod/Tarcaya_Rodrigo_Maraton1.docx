N = int(input("Escriba un numero<=3 y >=30: "))
if 3<=N<=30:
    def factorial(n):
        if n == 0:
            return 1
        else:
            return n * factorial(n - 1)
print("El factorial de N es: ")
print(factorial(N))
print("La suma de los numeros anteriores a N que sean multiplos de 3 pero no de 5: ")
t=0
for i in range (0, N):
    if i%5==0:
        print("", end="")
    else:
        if i%3==0:
                t+=i
 
print (t)
print("La suma de todos los pares menos la suma de los impares")
total=0
N+1
for i in range (0, N):
	if i % 2 == 0:
			total+=i
 
print ("suma de pares: ",total)
totali=0
N+1
for i in range (0, N):
    if i % 2 == 1:
        totali+=i
 
print ("suma de impares: ", totali)
resta=total-totali
print("total de la resta", resta)

    
    
    





    


